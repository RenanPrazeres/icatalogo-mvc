<div style="width: 100%; text-align: center;">

    <img src="https://image.flaticon.com/icons/png/512/103/103085.png" width="300" />

    <h2>PÁGINA NÃO ENCONTRADA</h2>

    <br />
    <a href="/">Voltar</a>

</div>