<?php

//aplicando a psr-4 - autoload
require("../vendor/autoload.php");

$app = new \App\Core\Router();